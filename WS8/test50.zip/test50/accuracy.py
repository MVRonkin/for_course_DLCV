import pandas as pd
import numpy as np
from skimage.draw import polygon
from PIL import Image
import matplotlib.patches as patches

import os

def contours2mask(contours, shape):
    mask = np.zeros(shape)
    rr, cc = polygon(contours[:, 0], contours[:, 1], shape)
    mask[rr, cc] = 1
    return mask

def dice_(pred, target, smooth=1):
    #flatten label and prediction tensors
    target = Image.fromarray(target)
    target = np.array(target.resize(Image.fromarray(pred).size))
    
    pred    = pred.reshape(-1)
    target = target.reshape(-1)
    intersection = (pred * target).sum()                            
    return  (2.*intersection + smooth)/(pred.sum() + target.sum() + smooth) 

def get_masks(df, id_):
    gtmask_    = np.array(df['ground_trugh'].values[id_])
    pred_mask_ = np.array(df['mask'].values[id_])                      
    gtmask     = contours2mask(gtmask_, df['im_shape'].values[id_][:2])
    predmask   = contours2mask(pred_mask_, df['shape'].values[id_][:2])
    
    return gtmask, predmask

def submission(df):
    dices = []
    for id_ in range(df.shape[0]):
        gtmask, predmask = get_masks(df, id_)
        dices +=[dice_( gtmask, predmask)]
    return pd.DataFrame(np.array(dices))

def create_df(addition = 'demo_.json', predicts = 'intermediate.json' ):
    addition  = pd.read_json(addition,  orient = 'table')
    predicts = pd.read_json(predicts, orient = 'table')
    addition_ = addition.rename(columns={"fname": "old_name", "id":"ans_id", "mask":"ground_trugh", 'shape':'im_shape'})
    return addition_.merge(predicts,left_on='new_fname', right_on='fname')


def make_submission(path_intermediate = os.path.join(os.getcwd(),'intermediate.json')):
    path_addition     = os.path.join(os.getcwd(),'test50','addition.json') 
    df = create_df(addition = path_addition, predicts = path_intermediate )
    acc=submission(df)
    return acc
